'use strict';
const {
  app, BrowserWindow, ipcMain, session, Notification, dialog, Tray, Menu, nativeImage, shell, systemPreferences
} = require('electron');
const path = require('path');
const fs = require('fs');
const http = require('http');
const crypto = require('crypto');
const createBridge = require('./bridge');

const CFG = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));
const APP_NAME = CFG.appName || 'Dr. Wael';

let win = null;
let tray = null;
let quitting = false;
let PORT = 0;
let bridge = null;
let autoUpdater = null;

if (!app.requestSingleInstanceLock()) {
  app.quit();
}
app.setAppUserModelId('com.drwael.desktop');

// ------------------------------------------------------------------ مخزن المكتبات (يعمل بدون إنترنت)
const LIB_HOSTS = [
  ['www.gstatic.com', '/firebasejs/'],
  ['cdnjs.cloudflare.com', '/ajax/libs/'],
  ['cdn.jsdelivr.net', '/npm/pdfjs-dist']
];
const KATEX = 'https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9/';
const PREFETCH = [
  'https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js',
  'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth-compat.js',
  'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore-compat.js',
  KATEX + 'katex.min.css',
  KATEX + 'katex.min.js',
  KATEX + 'contrib/mhchem.min.js',
  KATEX + 'contrib/auto-render.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js'
];
const libAllowed = (u) => u.protocol === 'https:' && LIB_HOSTS.some(([h, p]) => u.hostname === h && u.pathname.startsWith(p));
const sha1 = (s) => crypto.createHash('sha1').update(s).digest('hex');
const cacheDir = () => path.join(app.getPath('userData'), 'libcache');
let fetchSession = null;

function mimeFor(url, header) {
  const h = (header || '').split(';')[0].trim();
  if (h && h !== 'application/octet-stream') return h;
  const p = url.split('?')[0];
  if (p.endsWith('.js') || p.endsWith('.mjs')) return 'application/javascript';
  if (p.endsWith('.css')) return 'text/css';
  if (p.endsWith('.woff2')) return 'font/woff2';
  if (p.endsWith('.json')) return 'application/json';
  return 'application/octet-stream';
}

async function fetchToCache(url) {
  try {
    fs.mkdirSync(cacheDir(), { recursive: true });
    const r = await fetchSession.fetch(url);
    if (!r.ok) return false;
    const buf = Buffer.from(await r.arrayBuffer());
    const f = path.join(cacheDir(), sha1(url));
    fs.writeFileSync(f + '.tmp', buf);
    fs.renameSync(f + '.tmp', f);
    fs.writeFileSync(f + '.m', mimeFor(url, r.headers.get('content-type')));
    return true;
  } catch (e) {
    return false;
  }
}
const isCached = (url) => fs.existsSync(path.join(cacheDir(), sha1(url) + '.m'));

async function prefetchLibs() {
  for (const u of PREFETCH) if (!isCached(u)) await fetchToCache(u);
  try {
    const css = fs.readFileSync(path.join(cacheDir(), sha1(KATEX + 'katex.min.css')), 'utf8');
    const fonts = new Set([...css.matchAll(/url\((fonts\/[^)]+?\.woff2)\)/g)].map((m) => m[1]));
    for (const f of fonts) if (!isCached(KATEX + f)) await fetchToCache(KATEX + f);
  } catch (e) { /* تجاهل */ }
}

// ------------------------------------------------------------------ سكربت الإقلاع المحقون في الصفحة
function bootScript() {
  return `(function(){
var h=window.__dwHost;if(!h)return;
window.DWNative={desktop:true,platform:${JSON.stringify(process.platform)},postMessage:function(s){h.send(String(s))},onmessage:null};
h.onReply(function(m){try{if(window.DWNative.onmessage)window.DWNative.onmessage({data:m})}catch(e){}});
var D=function(k,m,d){try{var r=h.dialog(k,m==null?'':String(m),d==null?'':String(d),document.documentElement.lang||'ar',document.documentElement.dir!=='ltr');return r===undefined?null:r}catch(e){return null}};
window.alert=function(m){D('alert',m)};
window.confirm=function(m){return D('confirm',m)===true};
window.prompt=function(m,d){var r=D('prompt',m,d);return typeof r==='string'?r:null};
})();`;
}

function pageHtml() {
  const html = fs.readFileSync(path.join(__dirname, 'app', 'index.html'), 'utf8');
  return html.replace('<head>', '<head><script>' + bootScript() + '</script>');
}

// ------------------------------------------------------------------ خادم محلي صغير لعرض الصفحة
function startServer() {
  return new Promise((resolve) => {
    const srv = http.createServer(async (req, res) => {
      try {
        const u = new URL(req.url, 'http://localhost');
        if (req.method === 'GET' && (u.pathname === '/' || u.pathname === '/index.html')) {
          res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' });
          return res.end(pageHtml());
        }
        if (req.method === 'GET' && u.pathname === '/__lib') {
          let t;
          try { t = new URL(u.searchParams.get('u') || ''); } catch (e) { res.writeHead(400); return res.end(); }
          if (!libAllowed(t)) { res.writeHead(403); return res.end(); }
          if (!isCached(t.href) && !(await fetchToCache(t.href))) { res.writeHead(504); return res.end(); }
          const f = path.join(cacheDir(), sha1(t.href));
          res.writeHead(200, {
            'content-type': fs.readFileSync(f + '.m', 'utf8'),
            'access-control-allow-origin': '*',
            'cache-control': 'public, max-age=31536000'
          });
          return fs.createReadStream(f).pipe(res);
        }
        if (u.pathname === '/favicon.ico') { res.writeHead(204); return res.end(); }
        res.writeHead(404);
        return res.end();
      } catch (e) {
        res.writeHead(500);
        return res.end();
      }
    });
    srv.once('error', () => {
      // المنفذ المفضّل مشغول: نستخدم منفذًا عشوائيًا
      srv.listen(0, '127.0.0.1', () => { PORT = srv.address().port; resolve(); });
    });
    srv.listen(CFG.preferredPort || 47831, '127.0.0.1', () => { PORT = srv.address().port; resolve(); });
  });
}

// ------------------------------------------------------------------ نوافذ التنبيه بتصميم التطبيق
const dlgPending = new Map();

function brandDialog(o) {
  return new Promise((resolve) => {
    const parent = win && win.isVisible() ? win : undefined;
    const w = new BrowserWindow({
      parent, modal: !!parent, width: 460, height: 260, useContentSize: true,
      frame: false, transparent: true, resizable: false, minimizable: false, maximizable: false,
      fullscreenable: false, show: false, skipTaskbar: true, backgroundColor: '#00000000',
      webPreferences: {
        preload: path.join(__dirname, 'dialog-preload.js'), contextIsolation: true, sandbox: true, nodeIntegration: false
      }
    });
    w.setContentProtection(true);
    const def = o.k === 'confirm' ? false : o.k === 'prompt' ? null : true;
    let done = false;
    const fin = (v) => {
      if (done) return;
      done = true;
      dlgPending.delete(w.webContents.id);
      resolve(v);
      try { w.close(); } catch (e) { /* تجاهل */ }
    };
    dlgPending.set(w.webContents.id, { fin, w, parent });
    w.on('closed', () => fin(def));
    w.webContents.once('did-finish-load', () => w.webContents.send('dlg:init', o));
    w.loadFile(path.join(__dirname, 'dialog.html'));
  });
}

ipcMain.on('dlg:done', (e, v) => { const p = dlgPending.get(e.sender.id); if (p) p.fin(v); });
ipcMain.on('dlg:size', (e, h) => {
  const p = dlgPending.get(e.sender.id);
  if (!p) return;
  const height = Math.max(150, Math.min(Math.ceil(Number(h) || 260), 640));
  p.w.setContentSize(460, height);
  if (p.parent && !p.parent.isDestroyed()) {
    const b = p.parent.getBounds();
    p.w.setPosition(Math.round(b.x + (b.width - 460) / 2), Math.round(b.y + (b.height - height) / 2));
  } else {
    p.w.center();
  }
  p.w.show();
});

const trusted = (e) => {
  try { return e.senderFrame.url.startsWith('http://localhost:' + PORT + '/'); } catch (x) { return false; }
};

ipcMain.on('dw:dialog', (e, o) => {
  if (!trusted(e) || !o || typeof o !== 'object') { e.returnValue = null; return; }
  const k = ['alert', 'confirm', 'prompt'].includes(o.k) ? o.k : 'alert';
  brandDialog({ k, m: String(o.m || '').slice(0, 3000), d: String(o.d || '').slice(0, 1000), l: o.l === 'en' ? 'en' : 'ar', rtl: o.rtl !== false })
    .then((v) => { e.returnValue = v === undefined ? null : v; });
});

ipcMain.on('dw:msg', async (e, raw) => {
  if (!trusted(e) || typeof raw !== 'string' || raw.length > 60 * 1024 * 1024) return;
  const r = await bridge.handle(raw);
  if (r && !e.sender.isDestroyed()) e.sender.send('dw:reply', JSON.stringify(r));
});

// ------------------------------------------------------------------ النافذة والأيقونة
const iconPath = (name) => path.join(__dirname, 'assets', 'icons', (name || 'Default') + '.png');
const appIcon = () => nativeImage.createFromPath(iconPath(bridge ? bridge.state().icon : 'Default'));

function showWin() {
  if (!win) return;
  if (win.isMinimized()) win.restore();
  win.show();
  win.focus();
}

function createWindow() {
  win = new BrowserWindow({
    width: 1000, height: 820, minWidth: 360, minHeight: 560,
    title: APP_NAME, icon: appIcon(), backgroundColor: '#B22127', autoHideMenuBar: true, show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: true, nodeIntegration: false,
      spellcheck: false, autoplayPolicy: 'no-user-gesture-required', devTools: !app.isPackaged
    }
  });
  win.setContentProtection(true); // يمنع لقطة الشاشة وتسجيلها (ويندوز وماك)
  win.once('ready-to-show', () => win.show());
  win.on('close', (ev) => {
    if (!quitting) { ev.preventDefault(); win.hide(); }
  });
  const origin = 'http://localhost:' + PORT;
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^(https?:|mailto:|tel:)/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (ev, url) => {
    if (!url.startsWith(origin + '/')) {
      ev.preventDefault();
      if (/^(https?:|mailto:|tel:)/i.test(url)) shell.openExternal(url);
    }
  });
  win.loadURL(origin + '/');
}

function createTray() {
  try {
    const img = appIcon().resize({ width: 20, height: 20 });
    tray = new Tray(img);
    tray.setToolTip(APP_NAME);
    tray.setContextMenu(Menu.buildFromTemplate([
      { label: 'فتح / Open', click: showWin },
      { label: 'التحقق من التحديثات / Check for updates', click: () => checkUpdates(true) },
      { type: 'separator' },
      { label: 'خروج / Quit', click: () => { quitting = true; app.quit(); } }
    ]));
    tray.on('click', showWin);
  } catch (e) { /* بعض بيئات لينكس بلا Tray */ }
}

// ------------------------------------------------------------------ التحديثات (ويندوز ولينكس AppImage)
function checkUpdates(manual) {
  if (!app.isPackaged) return;
  if (process.platform === 'darwin') {
    if (manual) shell.openExternal('https://github.com/khaledahmed34567/DrWael-Desktop/releases/latest');
    return;
  }
  try {
    if (!autoUpdater) {
      ({ autoUpdater } = require('electron-updater'));
      autoUpdater.autoDownload = true;
      autoUpdater.on('update-downloaded', (info) => {
        brandDialog({
          k: 'confirm', l: 'ar', rtl: true,
          m: 'تحديث جديد (الإصدار ' + info.version + ') جاهز. هل تريد إعادة التشغيل الآن لتثبيته؟',
          okText: 'إعادة التشغيل', cancelText: 'لاحقًا'
        }).then((yes) => { if (yes) { quitting = true; autoUpdater.quitAndInstall(); } });
      });
      autoUpdater.on('error', () => { /* تجاهل أخطاء الشبكة */ });
    }
    autoUpdater.checkForUpdates().catch(() => {});
  } catch (e) { /* تجاهل */ }
}

// ------------------------------------------------------------------ التشغيل
app.on('second-instance', showWin);
app.on('before-quit', () => { quitting = true; });
app.on('activate', showWin);
app.on('window-all-closed', () => { /* نبقى في الخلفية (Tray) للتذكيرات */ });

app.whenReady().then(async () => {
  if (process.platform === 'darwin') {
    Menu.setApplicationMenu(Menu.buildFromTemplate([
      { role: 'appMenu' }, { role: 'editMenu' }, { role: 'windowMenu' }
    ]));
  } else {
    Menu.setApplicationMenu(null);
  }

  fetchSession = session.fromPartition('libfetch');
  const ses = session.defaultSession;
  const okPerms = ['notifications', 'fullscreen', 'clipboard-sanitized-write', 'media'];
  ses.setPermissionRequestHandler((wc, perm, cb) => cb(perm !== 'media' && okPerms.includes(perm)));
  ses.setPermissionCheckHandler((wc, perm) => perm !== 'media' && okPerms.includes(perm));
  ses.on('will-download', (ev) => ev.preventDefault());

  bridge = createBridge({
    cfg: CFG,
    statePath: path.join(app.getPath('userData'), 'state.json'),
    version: app.getVersion(),
    now: () => Date.now(),
    notify: (t, b) => {
      if (!Notification.isSupported()) return;
      const n = new Notification({ title: t || APP_NAME, body: b || '', icon: appIcon() });
      n.on('click', showWin);
      n.show();
    },
    saveFile: async (name, mime, buf) => {
      const r = await dialog.showSaveDialog(win, { defaultPath: path.join(app.getPath('downloads'), name) });
      if (r.canceled || !r.filePath) return false;
      fs.writeFileSync(r.filePath, buf);
      return true;
    },
    openExternal: (url) => shell.openExternal(url),
    touchId: async (why) => {
      if (process.platform === 'darwin' && systemPreferences.canPromptTouchID()) {
        try { await systemPreferences.promptTouchID(why); return true; } catch (e) { return false; }
      }
      return true; // على ويندوز/لينكس تحمي الصفحة نفسها برمز PIN
    },
    setIcon: (name) => {
      const img = nativeImage.createFromPath(iconPath(name));
      if (img.isEmpty()) return false;
      if (win) win.setIcon(img);
      if (process.platform === 'darwin' && app.dock) app.dock.setIcon(img);
      if (tray) tray.setImage(img.resize({ width: 20, height: 20 }));
      return true;
    },
    checkUpdate: () => checkUpdates(true)
  });

  await startServer();

  // تحويل طلبات مكتبات الـ CDN إلى المخزن المحلي (يعمل بدون إنترنت بعد أول تشغيل)
  ses.webRequest.onBeforeRequest(
    { urls: ['https://www.gstatic.com/firebasejs/*', 'https://cdnjs.cloudflare.com/ajax/libs/*', 'https://cdn.jsdelivr.net/npm/pdfjs-dist*'] },
    (details, cb) => {
      try {
        if (libAllowed(new URL(details.url)) && details.method === 'GET') {
          cb({ redirectURL: 'http://localhost:' + PORT + '/__lib?u=' + encodeURIComponent(details.url) });
          return;
        }
      } catch (e) { /* تجاهل */ }
      cb({});
    }
  );

  createWindow();
  createTray();
  setInterval(() => bridge.tick(), 20000);
  setTimeout(() => { prefetchLibs(); checkUpdates(false); }, 4000);
});
